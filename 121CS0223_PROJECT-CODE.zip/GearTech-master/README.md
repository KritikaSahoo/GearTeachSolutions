## GearTech Solutions

It's an e-commerce site, where customer can buy any auto parts online.

Exotic Parts is Published on: https://kritikasahoo.github.io/GearTech/
### Login Credentials:

Email Address: exoticparts@gmail.com

Password: ExoticParts04
